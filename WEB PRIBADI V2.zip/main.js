// Tambahkan interaktivitas jika diperlukan
document.addEventListener('DOMContentLoaded', function () {
    console.log('Website siap digunakan!');
});